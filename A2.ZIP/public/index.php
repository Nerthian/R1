<?php
    require_once __DIR__.'/../vendor/autoload.php';
    $app = new Silex\Application();
   // $app['debug'] = true;

    $app->register(new Silex\Provider\TwigServiceProvider(), array(
    'twig.path' => __DIR__ . '/views'));

    $app->get('/', function() use ($app) {
		//
		$xml  = new DomDocument;
		$xmlfile    = "tasks.xml";
		$xml->load($xmlfile);
		$elements = $xml->getElementsByTagName('tasks');
		//
		$tasks = array(
			'isCompleted' => false,
			'taskname' => '',
		);
		//
		$data = array ();
		foreach($elements as $node){
			foreach($node->childNodes as $child) {
				$tasks['taskname'] =  $child->nodeValue;
				$data[]=$tasks;
			}
		}
		//
        return $app['twig']->render('view.twig', ['tasks'=> $data]);

    });


   $app->run();

?>
