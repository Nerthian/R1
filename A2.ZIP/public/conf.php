﻿<?php
if (isset ($argv[0])) 
{
	$xml  = new DomDocument;
	$xml->preserveWhiteSpace = false;
	$xml->formatOutput = true;
	$xmlfile    = "tasks.xml";
	$xml->load($xmlfile);
	//			
	$p1 = $xml->getElementsByTagName('tasks')->item(0);			
	// 
	$rootElement = $xml->createElement('task',''); 
	$c1Element = $xml->createElement('taskname',$argv[1]);
	// 
	$p1->appendChild($rootElement);
	$rootElement->appendChild($c1Element);
	$xml->save('tasks.xml'); 
};


?> 